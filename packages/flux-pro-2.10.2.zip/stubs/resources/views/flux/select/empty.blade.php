{{-- This file exists for backwards compatibility... --}}
<x-select.option.empty {{ $attributes }}>
    {{ $slot }}
</x-select.option.empty>