@blaze

<div {{ $attributes->class('flex gap-4') }} data-flux-kanban>
    {{ $slot }}
</div>
